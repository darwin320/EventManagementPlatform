import { EventStatus } from './event-status.enum';

export interface EventModel  {
  id: number;
  title: string;
  dateTime: string;     // ISO string
  location: string;
  description: string;
  status: EventStatus;
}
