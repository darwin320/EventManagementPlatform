export enum EventStatus {
  Upcoming  = 0,
  Attending = 1,
  Maybe     = 2,
  Declined  = 3
}
