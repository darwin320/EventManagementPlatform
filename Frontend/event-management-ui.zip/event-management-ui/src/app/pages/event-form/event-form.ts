import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';

import { EventService } from '../../services/event.service';
import { EventStatus } from '../../models/event-status.enum';
import { EventModel } from '../../models/event.model';

@Component({
  selector: 'app-event-form',
  standalone: true,
  templateUrl: './event-form.html',                
  styleUrls: ['./event-form.scss'],                 
  imports: [CommonModule, ReactiveFormsModule, RouterModule]
})
export class EventFormComponent implements OnInit {

  public EventStatus = EventStatus;
  public statuses = [
    { value: EventStatus.Upcoming,  label: 'Upcoming'  },
    { value: EventStatus.Attending, label: 'Attending' },
    { value: EventStatus.Maybe,     label: 'Maybe'     },
    { value: EventStatus.Declined,  label: 'Declined'  }
  ];

  public id: number | null = null;
  public form!: FormGroup;

  constructor(
    private fb: FormBuilder,
    private svc: EventService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  public ngOnInit(): void {

    this.form = this.fb.group({
      title: ['', Validators.required],
      dateTime: ['', Validators.required],
      location: ['', Validators.required],
      description: [''],
      status: [EventStatus.Upcoming, Validators.required]
    });

  
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    if (this.id) {
      this.svc.get(this.id).subscribe((ev: EventModel) => this.form.patchValue(ev));
    }
  }

  public save(): void {
    if (this.form.invalid) { return; }

    const dto = this.form.value;
    const done = () => this.router.navigate(['/events']);

    this.id
      ? this.svc.update(this.id, dto).subscribe(done)
      : this.svc.create(dto).subscribe(done);
  }
}
