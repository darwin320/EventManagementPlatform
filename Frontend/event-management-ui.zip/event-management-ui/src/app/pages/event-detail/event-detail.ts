import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';

import { EventService } from '../../services/event.service';
import { EventModel } from '../../models/event.model';
import { EventStatus } from '../../models/event-status.enum';

@Component({
  selector: 'app-event-detail',
  standalone: true,
  templateUrl: './event-detail.html',
  styleUrls: ['./event-detail.scss'],
  imports: [CommonModule, RouterModule]
})
export class EventDetailComponent implements OnInit {

  public event?: EventModel;        
  public EventStatus = EventStatus;  

  constructor(
    private route: ActivatedRoute,
    private svc: EventService,
    private router: Router
  ) {}

  public ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (id) {
      this.svc.get(id).subscribe({
        next: ev => { this.event = ev; },
        error: () => { alert('Event not found'); this.router.navigate(['/events']); }
      });
    }
  }

  public delete(): void {
    if (!this.event) { return; }
    if (confirm('Delete this event?')) {
      this.svc.delete(this.event.id).subscribe(() => this.router.navigate(['/events']));
    }
  }
}
