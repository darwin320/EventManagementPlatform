import { Component, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { EventService } from '../../services/event.service';
import { EventModel } from '../../models/event.model';

@Component({
  selector: 'app-events-list',
  standalone: true,
  templateUrl: './events-list.html',
  imports: [CommonModule, FormsModule, RouterModule, DatePipe]
})
export class EventsListComponent implements OnInit {

  public events: EventModel[] = [];
  public filter = '';

  constructor(private service: EventService) {}

  public ngOnInit(): void {
    this.load();
  }

  public load(): void {
    const query = this.filter ? `?title=${this.filter}` : '';
    this.service.getAll(query).subscribe((data: EventModel[]) => { this.events = data; });
  }

  public delete(id: number): void {
    if (confirm('Delete event?')) {
      this.service.delete(id).subscribe(() => this.load());
    }
  }
}
