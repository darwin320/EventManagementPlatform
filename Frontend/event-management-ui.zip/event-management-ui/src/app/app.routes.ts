import { Routes } from '@angular/router';
import { EventsListComponent } from './pages/events-list/events-list';
import { EventFormComponent } from './pages/event-form/event-form';
import { EventDetailComponent } from './pages/event-detail/event-detail';

export const routes: Routes = [
  { path: '', redirectTo: 'events', pathMatch: 'full' },
  { path: 'events', component: EventsListComponent },
  { path: 'events/new', component: EventFormComponent },
  { path: 'events/:id', component: EventDetailComponent },
  { path: 'events/:id/edit', component: EventFormComponent },
  { path: '**', redirectTo: 'events' }
];
