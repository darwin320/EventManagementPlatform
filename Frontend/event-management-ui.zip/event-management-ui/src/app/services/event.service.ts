// src/app/services/event.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { EventModel } from '../models/event.model';

@Injectable({ providedIn: 'root' })
export class EventService {

  private readonly api = `${environment.apiUrl}/events`;

  constructor(private http: HttpClient) {}

  public getAll(query: string = ''): Observable<EventModel[]> {
    return this.http.get<EventModel[]>(`${this.api}${query}`);
  }

  public get(id: number): Observable<EventModel> {
    return this.http.get<EventModel>(`${this.api}/${id}`);
  }

  public create(model: Omit<EventModel, 'id'>): Observable<EventModel> {
    return this.http.post<EventModel>(this.api, model);
  }

  public update(id: number, model: Omit<EventModel, 'id'>): Observable<void> {
    return this.http.put<void>(`${this.api}/${id}`, model);
  }

  public delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.api}/${id}`);
  }
}
